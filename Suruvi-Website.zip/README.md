# Suruvi Website
A responsive static website for Suruvi, designed from the supplied website reference video.

## Files
- `index.html` — page structure and content
- `styles.css` — responsive styling and visual design
- `script.js` — mobile navigation and footer year

Open `index.html` locally, or enable GitHub Pages in the repository settings to publish it.
